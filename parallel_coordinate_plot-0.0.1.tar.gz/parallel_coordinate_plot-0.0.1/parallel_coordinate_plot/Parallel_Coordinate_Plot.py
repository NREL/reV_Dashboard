# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class Parallel_Coordinate_Plot(Component):
    """A Parallel_Coordinate_Plot component.
Custom Parallel Coordinate Plot Component for Dash Below are the following Props accepted by the component
The ID used to identify this component in Dash callbacks.

REQUIRED
id for component
id: PropTypes.string,


REQUIRED
JSON row oriented data.  (For embedded uncertainty view this must be oriented  stdev_qoi1 | mean_qoi1 | stdev_qoi2 | mean_qoi2 ... for example data look in ./data/ folder )
row_Data: PropTypes.object,

REQUIRED
JSON column oriented data
data_Info: PropTypes.object,

NOT REQUIRED
brush_Data to return to the app
activeObjs: PropTypes.array,


REQUIRED
The uncertainty toggle setting
uncertainty: PropTypes.bool,

Keyword arguments:
- id (string; optional): The ID used to identify this component in Dash callbacks.
- row_Data (dict; optional): JSON row oriented data.
- data_Info (dict; optional): JSON column oriented data
- activeObjs (list; optional): brush_Data to return to the app
- uncertainty (boolean; optional): The uncertainty toggle setting"""
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, row_Data=Component.UNDEFINED, data_Info=Component.UNDEFINED, activeObjs=Component.UNDEFINED, uncertainty=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'row_Data', 'data_Info', 'activeObjs', 'uncertainty']
        self._type = 'Parallel_Coordinate_Plot'
        self._namespace = 'parallel_coordinate_plot'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'row_Data', 'data_Info', 'activeObjs', 'uncertainty']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(Parallel_Coordinate_Plot, self).__init__(**args)
