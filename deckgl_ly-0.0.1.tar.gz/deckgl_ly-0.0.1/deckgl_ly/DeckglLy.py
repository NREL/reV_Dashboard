# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class DeckglLy(Component):
    """A DeckglLy component.
DeckGL Wrapper

Keyword arguments:
- id (string; optional): The ID used to identify this component in Dash callbacks.
- data (dict; optional): The data
- mapboxtoken (string; required): The user's mapbox token.
- viewState (dict; default {
  longitude: -118.5,
  latitude: 34.0,
  zoom: 8,
  pitch: 0,
  bearing: 0
}): Viewport settings
- layers (list; optional): Array of dict's describing mapbox layers
- mapStyle (string; optional): Mapbox Style
- clickValue (string; optional): Click handler"""
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, data=Component.UNDEFINED, mapboxtoken=Component.REQUIRED, viewState=Component.UNDEFINED, layers=Component.UNDEFINED, mapStyle=Component.UNDEFINED, clickValue=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'data', 'mapboxtoken', 'viewState', 'layers', 'mapStyle', 'clickValue']
        self._type = 'DeckglLy'
        self._namespace = 'deckgl_ly'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'data', 'mapboxtoken', 'viewState', 'layers', 'mapStyle', 'clickValue']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in ['mapboxtoken']:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(DeckglLy, self).__init__(**args)
